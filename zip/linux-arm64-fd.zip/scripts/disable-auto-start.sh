#!/bin/bash

rm ~/.config/autostart/sysmon.desktop

echo Autostart Removed
