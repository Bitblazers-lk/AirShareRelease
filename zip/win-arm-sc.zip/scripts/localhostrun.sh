#!/bin/bash

ssh -R 80:localhost:36120 ssh.localhost.run
