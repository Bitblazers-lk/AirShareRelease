#!/bin/bash

echo "I am taking a little nap"

sleep 3
echo "Bye"
systemctl suspend

