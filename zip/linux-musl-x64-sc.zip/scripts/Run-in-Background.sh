#!/bin/bash

screen -d -m airshare
